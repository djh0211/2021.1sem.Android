package com.example.heolle_beoltteok

data class scheduleData(var schedule:String)  {
    constructor() :this("noinfo")
}