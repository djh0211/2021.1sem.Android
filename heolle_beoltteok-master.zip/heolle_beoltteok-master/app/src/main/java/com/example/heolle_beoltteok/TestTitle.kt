package com.example.heolle_beoltteok

class TestTitle (var testTitle:String, var date:String)  {
    constructor() :this("noinfo","noinfo")
}