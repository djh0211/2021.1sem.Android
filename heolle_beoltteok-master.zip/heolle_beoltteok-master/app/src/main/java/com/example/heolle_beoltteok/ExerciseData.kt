package com.example.heolle_beoltteok

data class ExerciseData(var ename:String, var emin:String,var esec:String,var rmin:String,var rsec:String) {
    constructor():this(" "," "," "," "," ")
}