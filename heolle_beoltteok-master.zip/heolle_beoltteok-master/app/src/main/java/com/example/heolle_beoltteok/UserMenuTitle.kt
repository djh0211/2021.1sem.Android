package com.example.heolle_beoltteok

class UserMenuTitle(var title:String) {
    constructor() :this("noinfo")

}