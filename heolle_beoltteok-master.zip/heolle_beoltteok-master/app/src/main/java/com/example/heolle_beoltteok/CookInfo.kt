package com.example.heolle_beoltteok

data class CookInfo(
    var cookingName : String = "",
    var cookingTime : String = "",
    var cookingImg : String = ""
)
