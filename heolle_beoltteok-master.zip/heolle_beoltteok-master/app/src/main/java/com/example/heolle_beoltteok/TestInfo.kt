package com.example.heolle_beoltteok

data class TestInfo(
        var testName : String = "",
        var testTime : String = "",
        var testImg : String = "",
        var hour : String = "",
        var minute : String = "",
        var sec : String = ""

        )