package com.example.heolle_beoltteok

data class UserItemInfo(
    var itemName : String = "",
    var itemTime : String = "",
    var itemImg : String = "",
    var hour : String = "",
    var minute : String = "",
    var sec : String = ""

)